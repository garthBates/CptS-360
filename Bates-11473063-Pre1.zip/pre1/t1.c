//********** t1.c file ************
          #include <stdio.h>
int g;
main()
{
  int a,b,c;
  a = 1; b = 2;
  c = a + b;
  printf("c=%d\n", c);
}      